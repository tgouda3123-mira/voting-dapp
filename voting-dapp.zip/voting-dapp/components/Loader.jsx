import React from "react";

const Loader = () => {
  return (
    <div class="loader-wrapper">
      <div class="loader"></div>
    </div>
  );
};

export default Loader;
